<?php
namespace app\index\controller;

class Index extends \think\Controller
{
	  public function buttons()         
		    {                           
		    	return $this->fetch();    
		    }                           
		
		public function calendar()         
		    {                           
		    	return $this->fetch();    
		    }                           
		
		public function editors()         
		    {                           
		    	return $this->fetch();    
		    }                           
		
		public function form()         
		    {                           
		    	return $this->fetch();    
		    }                           
		
		public function index()         
		    {                           
		    	return $this->fetch();    
		    }                           
		
		public function rinterface()         
		    {                           
		    	return $this->fetch();    
		    }                           
		
		public function login()         
		    {                           
		    	return $this->fetch();    
		    }                           
		
		public function stats()         
		    {                           
		    	return $this->fetch();    
		    }                           
		
		public function tables()         
		    {                           
		    	return $this->fetch();    
		    }                           
		

                   
		
}                   