<?php
namespace app\index\controller;

class Index extends \think\Controller
{
	  public function basic_table()         
		    {                           
		    	return $this->fetch();    
		    }                           
		
		public function blank()         
		    {                           
		    	return $this->fetch();    
		    }                           
		
		public function buttons()         
		    {                           
		    	return $this->fetch();    
		    }                           
		
		public function calendar()         
		    {                           
		    	return $this->fetch();    
		    }                           
		
		public function chartjs()         
		    {                           
		    	return $this->fetch();    
		    }                           
		
		public function form_component()         
		    {                           
		    	return $this->fetch();    
		    }                           
		
		public function gallery()         
		    {                           
		    	return $this->fetch();    
		    }                           
		
		public function general()         
		    {                           
		    	return $this->fetch();    
		    }                           
		
		public function index()         
		    {                           
		    	return $this->fetch();    
		    }                           
		
		public function lock_screen()         
		    {                           
		    	return $this->fetch();    
		    }                           
		
		public function login()         
		    {                           
		    	return $this->fetch();    
		    }                           
		
		public function morris()         
		    {                           
		    	return $this->fetch();    
		    }                           
		
		public function panels()         
		    {                           
		    	return $this->fetch();    
    		}                           

	public function responsive_table()         
	    {                           
	    	return $this->fetch();    
	    }                           

	public function todo_list()         
	    {                           
	    	return $this->fetch();    
	    }                           

                          
		                      
       
}                   