<?php
namespace app\index\controller;

class Index extends \think\Controller
{
    public function calendar()            
		    {                                 
		    	return $this->fetch();          
		    }                                 
	  public function chart()             
        {                                 
        	return $this->fetch();                                      
        }                                 
    public function file_manager()        
        {                                 
        	return $this->fetch();          
        }                                 
    public function form()                
        {                                 
        	return $this->fetch();          
        }                                 
    public function gallery()             
        {                                 
        	return $this->fetch();          
        }                                 
    public function icon()                
        {                                 
        	return $this->fetch();          
        }                                 
    public function index()               
        {                                 
        	return $this->fetch();          
        }                                 
    public function login()               
        {                                 
        	return $this->fetch();          
        }                                 
    public function messages()            
        {                                 
        	return $this->fetch();          
        }                                 
    public function submenu()             
        {                                 
        	return $this->fetch();          
        }                                 
    public function submenu2()            
        {                                 
        	return $this->fetch();          
        }                                 
    public function submenu3()            
        {                                 
        	return $this->fetch();          
        }                                 
    public function table()               
        {                                 
        	return $this->fetch();          
        }                                 
    public function tasks()               
        {                                 
        	return $this->fetch();          
        }                                 
    public function typography()          
        {                                 
        	return $this->fetch();          
        }                                 
    public function ui()                  
        {                                 
        	return $this->fetch();          
        }                                 
    public function widgets()             
        {                                 
        	return $this->fetch();          
        }              
}                   