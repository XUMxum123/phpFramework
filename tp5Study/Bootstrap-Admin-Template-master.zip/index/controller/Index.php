<?php
namespace app\index\controller;

class Index extends \think\Controller
{
	    public function r403()         
	    {                           
	    	return $this->fetch('403');    
	    }                           

		public function r404()         
		    {                           
		    	return $this->fetch('404');    
		    }                           

		public function r405()         
		    {                           
		    	return $this->fetch('405');    
		    }                           

		public function r500()         
		    {                           
		    	return $this->fetch('500');    
		    }                           

		public function r503()         
		    {                           
		    	return $this->fetch('503');    
		    }                           

		public function alterne()         
		    {                           
		    	return $this->fetch();    
		    }                           

		public function bgcolor()         
		    {                           
		    	return $this->fetch();    
		    }                           

		public function bgimage()         
		    {                           
		    	return $this->fetch();    
		    }                           

		public function blank()         
		    {                           
		    	return $this->fetch();    
		    }                           

		public function boxed()         
		    {                           
		    	return $this->fetch();    
		    }                           

		public function button()         
		    {                           
		    	return $this->fetch();    
		    }                           

		public function calendar()         
		    {                           
		    	return $this->fetch();    
		    }                           

		public function chart()         
		    {                           
		    	return $this->fetch();    
		    }                           

		public function countdown()         
		    {                           
		    	return $this->fetch();    
		    }                           

		public function dashboard()         
		    {                           
		    	return $this->fetch();    
		    }                           

		public function file()         
		    {                           
		    	return $this->fetch();    
		    }                           

		public function fixed_header()         
		    {                           
		    	return $this->fetch();    
		    }                           

		public function fixed_header_boxed()         
		    {                           
		    	return $this->fetch();    
		    }                           

		public function fixed_header_fixed_mini_sidebar()         
		    {                           
		    	return $this->fetch();    
		    }                           

		public function fixed_header_menu()         
		    {                           
		    	return $this->fetch();    
		    }                           

		public function fixed_header_mini_sidebar()         
		    {                           
		    	return $this->fetch();    
		    }                           

		public function fixed_menu()         
		    {                           
		    	return $this->fetch();    
		    }                           

		public function fixed_menu_boxed()         
		    {                           
		    	return $this->fetch();    
		    }                           

		public function fixed_mini_sidebar()         
		    {                           
		    	return $this->fetch();    
		    }                           

		public function form_general()         
		    {                           
		    	return $this->fetch();    
		    }                           

		public function form_validation()         
		    {                           
		    	return $this->fetch();    
		    }                           

		public function form_wizard()         
		    {                           
		    	return $this->fetch();    
		    }                           

		public function form_wysiwyg()         
		    {                           
		    	return $this->fetch();    
		    }                           

		public function fxhmoxed()         
		    {                           
		    	return $this->fetch();    
		    }                           

		public function grid()         
		    {                           
		    	return $this->fetch();    
		    }                           

		public function icon()         
		    {                           
		    	return $this->fetch();    
		    }                           

		public function index()         
		    {                           
		    	return $this->fetch();    
		    }                           

		public function login()         
		    {                           
		    	return $this->fetch();    
		    }                           

		public function maps()         
		    {                           
		    	return $this->fetch();    
		    }                           

		public function no_header_sidebar()         
		    {                           
		    	return $this->fetch();    
		    }                           

		public function no_header()         
		    {                           
		    	return $this->fetch();    
		    }                           

		public function no_left_right_sidebar()         
		    {                           
		    	return $this->fetch();    
		    }                           

		public function no_left_sidebar()         
		    {                           
		    	return $this->fetch();    
		    }                           

		public function no_left_sidebar_main_search()         
		    {                           
		    	return $this->fetch();    
		    }                           

		public function no_main_search()         
		    {                           
		    	return $this->fetch();    
		    }                           

		public function no_right_sidebar()         
		    {                           
		    	return $this->fetch();    
		    }                           

		public function offline()         
		    {                           
		    	return $this->fetch();    
		    }                           

		public function panel()         
		    {                           
		    	return $this->fetch();    
		    }                           

		public function pricing()         
		    {                           
		    	return $this->fetch();    
		    }                           

		public function progress()         
		    {                           
		    	return $this->fetch();    
		    }                           

		public function sm()         
		    {                           
		    	return $this->fetch();    
		    }                           

		public function table()         
		    {                           
		    	return $this->fetch();    
		    }                           

		public function typography()         
		    {                           
		    	return $this->fetch();    
		    }                           

}                   