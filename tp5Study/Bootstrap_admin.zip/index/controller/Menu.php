<?php
namespace app\index\controller;

class Menu extends \think\Controller
{
		public function index()         
		    {                           
		    	return $this->fetch();    
		    }                           
		public function add()         
		    {                           
		    	return $this->fetch();    
		    }  
		public function edit()         
		    {                           
		    	return $this->fetch();    
		    }
}                   