<?php
namespace app\index\controller;

class Role extends \think\Controller
{
		public function index()         
		    {                           
		    	return $this->fetch();    
		    }                           
		public function add()         
		    {                           
		    	return $this->fetch();    
		    }  
		public function edit()         
		    {                           
		    	return $this->fetch();    
		    }
}                   