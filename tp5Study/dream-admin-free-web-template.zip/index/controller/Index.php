<?php
namespace app\index\controller;

class Index extends \think\Controller
{
	  public function chart()         
		    {                           
		    	return $this->fetch();    
		    }                           
		
		public function rempty()         
		    {                           
		    	return $this->fetch('empty');    
		    }                           
		
		public function form()         
		    {                           
		    	return $this->fetch();    
		    }                           
		
		public function index()         
		    {                           
		    	return $this->fetch();    
		    }                           
		
		public function table()         
		    {                           
		    	return $this->fetch();    
		    }                           
		
		public function tab_panel()         
		    {                           
		    	return $this->fetch();    
    		}                           

	public function ui_elements()         
	    {                           
    	return $this->fetch();    
    	}                           


             

}                   