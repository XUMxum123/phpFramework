<?php
namespace app\index\controller;

class Index extends \think\Controller
{
    		public function r404()
		    {
		    	return $this->fetch('404');
		    }
		public function r500()
		    {
		    	return $this->fetch('500');
		    }
		public function advanced()
		    {
		    	return $this->fetch();
		    }
		public function blank()
		    {
		    	return $this->fetch();
		    }
		public function boxed()
		    {
		    	return $this->fetch();
		    }
		public function buttons()
		    {
		    	return $this->fetch();
		    }
		public function calendar()
		    {
		    	return $this->fetch();
		    }
		public function chartjs()
		    {
		    	return $this->fetch();
		    }
		public function collapsed_sidebar()
		    {
		    	return $this->fetch();
		    }
		public function compose()
		    {
		    	return $this->fetch();
		    }
		public function data()
		    {
		    	return $this->fetch();
		    }
		public function editors()
		    {
		    	return $this->fetch();
		    }
		public function fixed()
		    {
		    	return $this->fetch();
		    }
		public function flot()
		    {
		    	return $this->fetch();
		    }
		public function general()
		    {
		    	return $this->fetch();
		    }
		public function icons()
		    {
		    	return $this->fetch();
		    }
		public function index()
		    {
		    	return $this->fetch();
		    }
		public function index2()
		    {
		    	return $this->fetch();
		    }
		public function inline()
		    {
		    	return $this->fetch();
		    }
		public function invoice_print()
		    {
		    	return $this->fetch();
		    }
		public function invoice()
		    {
		    	return $this->fetch();
		    }
		public function lockscreen()
		    {
		    	return $this->fetch();
		    }
		public function login()
		    {
		    	return $this->fetch();
		    }
		public function mailbox()
		    {
		    	return $this->fetch();
		    }
		public function modals()
		    {
		    	return $this->fetch();
		    }
		public function morris()
		    {
		    	return $this->fetch();
		    }
		public function pace()
		    {
		    	return $this->fetch();
		    }
		public function profile()
		    {
		    	return $this->fetch();
		    }
		public function read_mail()
		    {
		    	return $this->fetch();
		    }
		public function register()
		    {
		    	return $this->fetch();
		    }
		public function simple()
		    {
		    	return $this->fetch();
		    }
		public function sliders()
		    {
		    	return $this->fetch();
		    }
		public function starter()
		    {
		    	return $this->fetch();
		    }
		public function timeline()
		    {
		    	return $this->fetch();
		    }
		public function top_nav()
		    {
		    	return $this->fetch();
		    }
		public function ui_general()
		    {
		    	return $this->fetch();
		    }
		public function widgets()
		    {
		    	return $this->fetch();
		    }
		
}
