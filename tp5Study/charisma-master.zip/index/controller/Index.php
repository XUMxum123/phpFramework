<?php
namespace app\index\controller;

class Index extends \think\Controller
{
	  public function blank()         
		    {                           
		    	return $this->fetch();    
		    }                           

		public function calendar()         
		    {                           
		    	return $this->fetch();    
		    }                           

		public function chart()         
		    {                           
		    	return $this->fetch();    
		    }                           

		public function error1()         
		    {                           
		    	return $this->fetch('error');    
		    }                           

		public function form()         
		    {                           
		    	return $this->fetch();    
		    }                           

		public function gallery()         
		    {                           
		    	return $this->fetch();    
		    }                           

		public function grid()         
		    {                           
		    	return $this->fetch();    
		    }                           

		public function icon()         
		    {                           
		    	return $this->fetch();    
		    }                           

		public function index()         
		    {                           
		    	return $this->fetch();    
		    }                           

		public function login()         
		    {                           
		    	return $this->fetch();    
		    }                           

		public function table()         
		    {                           
		    	return $this->fetch();    
		    }                           

		public function tour()         
		    {                           
		    	return $this->fetch();    
		    }                           

		public function typography()         
		    {                           
		    	return $this->fetch();    
		    }                           

		public function ui()         
		    {                           
		    	return $this->fetch();    
		    }            
}                   