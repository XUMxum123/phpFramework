<?php
namespace app\index\controller;

class Index extends \think\Controller
{
	  public function blank()         
		    {                           
		    	return $this->fetch();    
		    }                           

		public function buttons()         
		    {                           
		    	return $this->fetch();    
		    }                           

		public function flot()         
		    {                           
		    	return $this->fetch();    
		    }                           

		public function forms()         
		    {                           
		    	return $this->fetch();    
		    }                           

		public function grid()         
		    {                           
		    	return $this->fetch();    
		    }                           

		public function icons()         
		    {                           
		    	return $this->fetch();    
		    }                           

		public function index()         
		    {                           
		    	return $this->fetch();    
		    }                           

		public function login()         
		    {                           
		    	return $this->fetch();    
		    }                           

		public function morris()         
		    {                           
		    	return $this->fetch();    
		    }                           

		public function notifications()         
		    {                           
		    	return $this->fetch();    
		    }                           

		public function panels_wells()         
		    {                           
		    	return $this->fetch();    
		    }                           

		public function tables()         
		    {                           
		    	return $this->fetch();    
		    }                           

		public function typography()         
		    {                           
		    	return $this->fetch();    
		    }                           
       
}                   